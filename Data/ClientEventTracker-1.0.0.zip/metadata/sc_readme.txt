Installation guide:

1. Install the package. It contains only files:

/ClientEventTracker.ashx
/ClientEventTracker.js
/bin/Sitecore.SharedSource.ClientEventTracker.dll 

2. Update web.config (this step is not mandatory, it just improves performance) - add the following string to the "IgnoreUrlPrefixes" setting: /ClientEventTracker.ashx.

3. Add the following code to the <head> section of the page where you want to track events:
<script src="/ClientEventTracker.js" type="text/javascript"></script>

4. And use the API as it shown in the example below:

var event=new AnalyticsPageEvent('Instant Demo', 'Some Text Here');
event.trigger();